from django.urls import path
from api.views import category_list, category_detail, CategoryListAPIView, CategoryDetailAPIView, PostListAPIView, PostDetailAPIView
from rest_framework_jwt.views import obtain_jwt_token

# urlpatterns = [
#     path('categories/', category_list),
#     path('categories/<int:category_id>/', category_detail)
# ]

urlpatterns = [
    path('login/', obtain_jwt_token),
    path('categories/', CategoryListAPIView.as_view()),
    path('categories/<int:pk>/', CategoryDetailAPIView.as_view()),
    path('posts/', PostListAPIView.as_view()),
    path('posts/<int:pk>/', PostDetailAPIView.as_view()),

]
