from django.shortcuts import render
from django.http.response import JsonResponse
from fact.models import Fact

def fact_list(request):
    facts = Fact.objects.all()
    facts_json = [fact.to_json() for fact in facts]
    return JsonResponse(facts_json, safe=False)

def fact_detail(request, fact_id):
    try:
        fact = Fact.objects.get(id=fact_id)
    except Fact.DoesNotExist as e:
        return JsonResponse({'message': str(e)}, status=400)
    return JsonResponse(fact.to_json())

