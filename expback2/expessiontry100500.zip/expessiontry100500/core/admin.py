from django.contrib import admin
from .models import PostImage, Post, Category, Fact


class PostImageInLine(admin.TabularInline):
    model = PostImage


@admin.register(Post)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('id', 'title', 'category', 'timestamp')
    inlines = (PostImageInLine,)


@admin.register(Category)
class CategoryAdmin(admin.ModelAdmin):
    list_display = ('id', 'name')


@admin.register(Fact)
class FactAdmin(admin.ModelAdmin):
    list_display = ('id', 'title')

