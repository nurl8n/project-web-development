from django.apps import AppConfig


class FactConfig(AppConfig):
    name = 'fact'
