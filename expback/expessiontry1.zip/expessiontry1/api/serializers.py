from rest_framework import serializers
from post.models import Category, Post


class CategorySerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField()

    def create(self, validated_data):
        category = Category.objects.create(name=validated_data.get('name'))
        return category

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name')
        instance.save()
        return instance

class CategorySerializer2(serializers.ModelSerializer):
    # in order to see description of posts
    posts = serializers.StringRelatedField(many=True, read_only=True)
    class Meta:
        model = Category
        # adding posts because related_name is posts
        fields = ('id', 'name', 'posts')

class PostSerializer(serializers.ModelSerializer):
    class Meta:
        model = Post
        fields = ('id', 'name', 'body', 'category')

