from rest_framework import serializers
from .models import Category, Post, PostImage, Fact


class CategorySerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    name = serializers.CharField()

    def create(self, validated_data):
        category = Category()
        category.name = validated_data.get('name')
        category.save()
        return category

    def update(self, instance, validated_data):
        instance.name = validated_data.get('name')
        instance.save()
        return instance


class ImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = PostImage
        fields = ('id', 'src',)


class PostSerializer(serializers.ModelSerializer):
    category = CategorySerializer()
    images = ImageSerializer(many=True)

    class Meta:
        model = Post
        fields = '__all__'


class PostCreateSerializer(serializers.Serializer):
    category_id = serializers.IntegerField()
    title = serializers.CharField()
    body = serializers.CharField()

    def create(self, validated_data):
        post = Post()
        post.title = validated_data.get('title')
        post.body = validated_data.get('body')
        post.category_id = validated_data.get('category_id')
        post.owner = validated_data.get('owner')
        post.save()
        return post

    def update(self, instance, validated_data):
        instance.title = validated_data.get('title')
        instance.body = validated_data.get('body')
        instance.category_id = validated_data.get('category_id')
        instance.save()
        return instance


class FactSerializer(serializers.ModelSerializer):
    class Meta:
        model = Fact
        fields = '__all__'
