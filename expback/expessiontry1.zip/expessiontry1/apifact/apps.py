from django.apps import AppConfig


class ApifactConfig(AppConfig):
    name = 'apifact'
