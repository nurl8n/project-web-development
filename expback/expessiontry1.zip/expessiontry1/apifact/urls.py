from django.urls import path
from apifact.views import category_list, category_detail, CategoryListAPIView, CategoryDetailAPIView

# urlpatterns = [
#     path('categories/', category_list),
#     path('categories/<int:category_id>/', category_detail)
# ]


urlpatterns = [
    path('categories/', CategoryListAPIView.as_view()),
    path('categories/<int:pk>/', CategoryDetailAPIView.as_view())
]

