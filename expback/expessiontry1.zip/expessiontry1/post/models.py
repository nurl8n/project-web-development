from django.db import models

class Category(models.Model):
    name = models.CharField(max_length=200)

    class Meta:
        verbose_name = 'Category'
        verbose_name_plural = 'Categories'

    def to_json(self):
        return {
            'id': self.id,
            'name': self.name
        }

    def __str__(self):
        return f'{self.id}: {self.name}'

class Post(models.Model):
    name = models.CharField(max_length=300)
    body = models.TextField(max_length=1000)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, null=True, related_name='posts')

    class Meta:
        verbose_name = 'Post'
        verbose_name_plural = 'Posts'

    def to_json(self):
        return {
            'id': self.id,
            'name': self.name,
            'body': self.body
        }

    def __str__(self):
        return f'{self.name}: {self.body} , {self.category}'
