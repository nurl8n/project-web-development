from django.contrib import admin

from fact.models import Fact, Category

@admin.register(Fact)
class FactAdmin(admin.ModelAdmin):
    list_display = ('id', 'name', 'body', 'category')
    search_fields = ('name', )
    list_filter = ('category', )
# admin.site.register(Fact)
admin.site.register(Category)
