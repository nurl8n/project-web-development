from django.contrib.auth.models import User
from django.db import models


class Category(models.Model):
    name = models.CharField(max_length=100, verbose_name="Название категории")

    class Meta:
        verbose_name = "Категория"
        verbose_name_plural = "Категории"

    def __str__(self):
        return f'{self.name}'


class Post(models.Model):
    title = models.CharField(max_length=200, verbose_name="Заглавие поста")
    body = models.TextField(verbose_name="Тело поста")
    timestamp = models.DateTimeField(auto_now_add=True, verbose_name='Время создания')
    likes = models.PositiveIntegerField(default=0, verbose_name='Понравилось')
    owner = models.ForeignKey(User,
                              on_delete=models.CASCADE,
                              verbose_name="Автор поста",
                              related_name="posts",
                              blank=True,
                              null=True)
    category = models.ForeignKey(Category,
                                 on_delete=models.CASCADE,
                                 blank=True,
                                 null=True,
                                 verbose_name="Категория поста",
                                 related_name="posts")

    class Meta:
        verbose_name = "Пост"
        verbose_name_plural = "Посты"

    def __str__(self):
        return f'{self.title} {self.category}'


class PostImage(models.Model):
    src = models.ImageField(upload_to='images/products', verbose_name='Картинка')
    product = models.ForeignKey(Post,
                                on_delete=models.CASCADE,
                                verbose_name='Пост',
                                related_name='images',
                                blank=True,
                                null=True)

    class Meta:
        verbose_name_plural = 'Картинки поста'


class Fact(models.Model):
    title = models.CharField(max_length=200, verbose_name="Заглавие факта")
    body = models.TextField(verbose_name="Тело факта")

    class Meta:
        verbose_name = "Факт"
        verbose_name_plural = "Факты"
