# from .views1 import category_list, category_detail
# from .views2 import category_list, category_detail
from .views_fbv import category_detail, category_list
from .views_cbv import CategoryListAPIView, CategoryDetailAPIView
