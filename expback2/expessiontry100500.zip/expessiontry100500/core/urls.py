from django.urls import path
from rest_framework.routers import DefaultRouter

from core.views import categories_list, get_category, get_category_posts
from core.views import PostListAPIView, PostDetailAPIView, FactViewSet, post_like


router = DefaultRouter()
router.register(r'facts', FactViewSet)
urlpatterns = router.urls

urlpatterns += [
    path('categories/', categories_list),
    path('categories/<int:pk>/', get_category),
    path('categories/<int:pk>/posts/', get_category_posts),
    path('posts/', PostListAPIView.as_view()),
    path('posts/<int:pk>/', PostDetailAPIView.as_view()),
    path('posts/<int:pk>/like/', post_like)
]
