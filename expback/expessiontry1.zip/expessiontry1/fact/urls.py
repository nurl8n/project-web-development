from django.urls import path
from fact.views import fact_list, fact_detail

urlpatterns = [
    path('facts/', fact_list),
    path('facts/<int:fact_id>/', fact_detail)
]
