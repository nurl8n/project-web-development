# from .views_exp import category_detail, category_list
# from .views_exp1 import category_detail, category_list
from .views_fbv import category_list, category_detail
# from .views_cbv import CategoryListAPIView, CategoryDetailAPIView
# from .views_generic_v1 import CategoryListAPIView, CategoryDetailAPIView
from .views_generic_v2 import CategoryListAPIView, CategoryDetailAPIView, PostListAPIView, PostDetailAPIView

